package com.example.spendsmart.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.spendsmart.data.entity.BudgetGoal

@Dao
interface BudgetGoalDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(goal: BudgetGoal)

    @Query("SELECT * FROM budget_goals WHERE userId = :userId AND month = :month LIMIT 1")
    fun getGoalForMonth(userId: Int, month: String): LiveData<BudgetGoal?>

    @Query("SELECT * FROM budget_goals WHERE userId = :userId AND month = :month LIMIT 1")
    suspend fun getGoalForMonthSync(userId: Int, month: String): BudgetGoal?
}
