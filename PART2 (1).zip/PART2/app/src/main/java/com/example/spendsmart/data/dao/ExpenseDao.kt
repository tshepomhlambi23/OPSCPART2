package com.example.spendsmart.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.spendsmart.data.entity.Expense

data class CategoryTotal(val categoryId: Int, val total: Double)

@Dao
interface ExpenseDao {
    @Insert
    suspend fun insert(expense: Expense): Long

    @Update
    suspend fun update(expense: Expense)

    @Delete
    suspend fun delete(expense: Expense)

    @Query("SELECT * FROM expenses WHERE userId = :userId ORDER BY date DESC, startTime DESC")
    fun getAllExpenses(userId: Int): LiveData<List<Expense>>

    @Query("SELECT * FROM expenses WHERE userId = :userId AND date BETWEEN :fromDate AND :toDate ORDER BY date DESC")
    fun getExpensesByDateRange(userId: Int, fromDate: String, toDate: String): LiveData<List<Expense>>

    @Query("SELECT * FROM expenses WHERE userId = :userId AND date BETWEEN :fromDate AND :toDate ORDER BY date DESC")
    suspend fun getExpensesByDateRangeSync(userId: Int, fromDate: String, toDate: String): List<Expense>

    @Query("SELECT categoryId, SUM(amount) as total FROM expenses WHERE userId = :userId AND date BETWEEN :fromDate AND :toDate GROUP BY categoryId")
    fun getTotalByCategory(userId: Int, fromDate: String, toDate: String): LiveData<List<CategoryTotal>>

    @Query("SELECT SUM(amount) FROM expenses WHERE userId = :userId AND date BETWEEN :fromDate AND :toDate")
    fun getTotalSpending(userId: Int, fromDate: String, toDate: String): LiveData<Double?>

    @Query("SELECT * FROM expenses WHERE id = :id")
    suspend fun getExpenseById(id: Int): Expense?
}
