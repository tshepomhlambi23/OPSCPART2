package com.example.spendsmart.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "budget_goals")
data class BudgetGoal(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: Int,
    val minMonthly: Double = 0.0,
    val maxMonthly: Double = 10000.0,
    val month: String // yyyy-MM
)
