package com.example.spendsmart.ui.category

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.spendsmart.R
import com.example.spendsmart.data.AppDatabase
import com.example.spendsmart.data.entity.Category
import com.example.spendsmart.databinding.ActivityCategoryBinding
import com.example.spendsmart.utils.SessionManager
import kotlinx.coroutines.launch

class CategoryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCategoryBinding
    private lateinit var db: AppDatabase
    private var userId = -1

    private val colors = listOf("#F44336","#E91E63","#9C27B0","#3F51B5","#2196F3",
        "#009688","#4CAF50","#FF9800","#795548","#607D8B")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCategoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Categories"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        db = AppDatabase.getDatabase(this)
        userId = SessionManager.getUserId(this)
        binding.rvCategories.layoutManager = LinearLayoutManager(this)

        loadCategories()

        binding.btnAddCategory.setOnClickListener { showAddDialog() }
    }

    private fun loadCategories() {
        db.categoryDao().getCategoriesByUser(userId).observe(this) { cats ->
            binding.rvCategories.adapter = CategoryAdapter(cats,
                onDelete = { cat ->
                    AlertDialog.Builder(this)
                        .setTitle("Delete Category")
                        .setMessage("Delete '${cat.name}'?")
                        .setPositiveButton("Delete") { _, _ ->
                            lifecycleScope.launch { db.categoryDao().delete(cat) }
                        }.setNegativeButton("Cancel", null).show()
                }
            )
        }
    }

    private fun showAddDialog() {
        val input = android.widget.EditText(this).apply { hint = "Category name" }
        var selectedColor = colors[0]

        AlertDialog.Builder(this)
            .setTitle("New Category")
            .setView(input)
            .setPositiveButton("Add") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    lifecycleScope.launch {
                        db.categoryDao().insert(Category(userId = userId, name = name, color = selectedColor))
                    }
                } else {
                    input.error = "Name cannot be empty"
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}

class CategoryAdapter(
    private val categories: List<Category>,
    private val onDelete: (Category) -> Unit
) : RecyclerView.Adapter<CategoryAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvCategoryName)
        val vColor: View = view.findViewById(R.id.vCategoryColor)
        val btnDelete: TextView = view.findViewById(R.id.btnDeleteCategory)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_category, parent, false)
        return VH(v)
    }

    override fun getItemCount() = categories.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val cat = categories[position]
        holder.tvName.text = cat.name
        try { holder.vColor.setBackgroundColor(Color.parseColor(cat.color)) } catch (e: Exception) {}
        holder.btnDelete.setOnClickListener { onDelete(cat) }
    }
}
