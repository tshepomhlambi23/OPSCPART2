package com.example.spendsmart.ui.dashboard

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import com.example.spendsmart.data.AppDatabase
import com.example.spendsmart.databinding.ActivityDashboardBinding
import com.example.spendsmart.ui.category.CategoryActivity
import com.example.spendsmart.ui.expense.AddExpenseActivity
import com.example.spendsmart.ui.expense.ExpenseListActivity
import com.example.spendsmart.ui.goals.BudgetGoalsActivity
import com.example.spendsmart.ui.login.LoginActivity
import com.example.spendsmart.ui.reports.ReportsActivity
import com.example.spendsmart.utils.SessionManager
import java.text.SimpleDateFormat
import java.util.*

class DashboardActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDashboardBinding
    private lateinit var db: AppDatabase
    private var userId = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = AppDatabase.getDatabase(this)
        userId = SessionManager.getUserId(this)

        binding.tvWelcome.text = "Welcome, ${SessionManager.getUsername(this)}!"

        loadDashboardData()

        binding.btnAddExpense.setOnClickListener {
            startActivity(Intent(this, AddExpenseActivity::class.java))
        }
        binding.btnViewExpenses.setOnClickListener {
            startActivity(Intent(this, ExpenseListActivity::class.java))
        }
        binding.btnCategories.setOnClickListener {
            startActivity(Intent(this, CategoryActivity::class.java))
        }
        binding.btnReports.setOnClickListener {
            startActivity(Intent(this, ReportsActivity::class.java))
        }
        binding.btnBudgetGoals.setOnClickListener {
            startActivity(Intent(this, BudgetGoalsActivity::class.java))
        }
        binding.btnLogout.setOnClickListener {
            SessionManager.clearSession(this)
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        loadDashboardData()
    }

    private fun loadDashboardData() {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val cal = Calendar.getInstance()
        val today = sdf.format(cal.time)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        val firstDay = sdf.format(cal.time)
        val monthKey = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Calendar.getInstance().time)

        // Observe total spending this month
        db.expenseDao().getTotalSpending(userId, firstDay, today).observe(this, Observer { total ->
            val spent = total ?: 0.0
            binding.tvTotalSpent.text = "Total Spent: R%.2f".format(spent)

            // Load budget goal and update progress
            db.budgetGoalDao().getGoalForMonth(userId, monthKey).observe(this, Observer { goal ->
                val maxGoal = goal?.maxMonthly ?: 10000.0
                val minGoal = goal?.minMonthly ?: 0.0
                val progress = if (maxGoal > 0) ((spent / maxGoal) * 100).toInt() else 0
                binding.progressBudget.progress = progress.coerceIn(0, 100)
                binding.tvBudgetStatus.text = "Budget: R%.2f / R%.2f (Max)".format(spent, maxGoal)

                when {
                    spent > maxGoal -> {
                        binding.tvBudgetStatus.setTextColor(getColor(android.R.color.holo_red_dark))
                        binding.tvBudgetAlert.text = "⚠ Over budget!"
                    }
                    spent > maxGoal * 0.8 -> {
                        binding.tvBudgetStatus.setTextColor(getColor(android.R.color.holo_orange_dark))
                        binding.tvBudgetAlert.text = "⚠ Nearing budget limit"
                    }
                    spent >= minGoal -> {
                        binding.tvBudgetStatus.setTextColor(getColor(android.R.color.holo_green_dark))
                        binding.tvBudgetAlert.text = "✓ On track"
                    }
                    else -> {
                        binding.tvBudgetAlert.text = "Min goal: R%.2f".format(minGoal)
                    }
                }
            })
        })
    }
}
