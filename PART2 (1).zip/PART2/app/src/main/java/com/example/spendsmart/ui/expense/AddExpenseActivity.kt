package com.example.spendsmart.ui.expense

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.example.spendsmart.data.AppDatabase
import com.example.spendsmart.data.entity.Expense
import com.example.spendsmart.databinding.ActivityAddExpenseBinding
import com.example.spendsmart.utils.SessionManager
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class AddExpenseActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddExpenseBinding
    private lateinit var db: AppDatabase
    private var userId = -1
    private var selectedCategoryId = -1
    private var photoPath: String? = null
    private var currentPhotoUri: Uri? = null

    companion object {
        private const val REQUEST_CAMERA = 100
        private const val REQUEST_IMAGE_PICK = 101
        private const val CAMERA_PERMISSION = 200
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddExpenseBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Add Expense"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        db = AppDatabase.getDatabase(this)
        userId = SessionManager.getUserId(this)

        setDefaultDateTime()
        loadCategories()

        binding.etDate.setOnClickListener { showDatePicker() }
        binding.etStartTime.setOnClickListener { showTimePicker(true) }
        binding.etEndTime.setOnClickListener { showTimePicker(false) }
        binding.btnAddPhoto.setOnClickListener { requestPhotoOptions() }
        binding.btnSave.setOnClickListener { saveExpense() }
    }

    private fun setDefaultDateTime() {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val tdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        val now = Calendar.getInstance()
        binding.etDate.setText(sdf.format(now.time))
        binding.etStartTime.setText(tdf.format(now.time))
        binding.etEndTime.setText(tdf.format(now.time))
    }

    private fun loadCategories() {
        db.categoryDao().getCategoriesByUser(userId).observe(this) { categories ->
            if (categories.isEmpty()) {
                Toast.makeText(this, "Please create a category first", Toast.LENGTH_LONG).show()
                finish()
                return@observe
            }
            val names = categories.map { it.name }
            val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, names)
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            binding.spinnerCategory.adapter = adapter
            binding.spinnerCategory.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                    selectedCategoryId = categories[pos].id
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
    }

    private fun showDatePicker() {
        val cal = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            binding.etDate.setText("%04d-%02d-%02d".format(y, m + 1, d))
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun showTimePicker(isStart: Boolean) {
        val cal = Calendar.getInstance()
        TimePickerDialog(this, { _, h, m ->
            val time = "%02d:%02d".format(h, m)
            if (isStart) binding.etStartTime.setText(time) else binding.etEndTime.setText(time)
        }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
    }

    private fun requestPhotoOptions() {
        val options = arrayOf("Take Photo", "Choose from Gallery")
        android.app.AlertDialog.Builder(this)
            .setTitle("Add Receipt Photo")
            .setItems(options) { _, which ->
                if (which == 0) checkCameraPermission() else openGallery()
            }.show()
    }

    private fun checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION)
        } else {
            openCamera()
        }
    }

    private fun openCamera() {
        val photoFile = File(getExternalFilesDir(Environment.DIRECTORY_PICTURES),
            "receipt_${System.currentTimeMillis()}.jpg")
        currentPhotoUri = FileProvider.getUriForFile(this, "${packageName}.provider", photoFile)
        photoPath = photoFile.absolutePath
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            putExtra(MediaStore.EXTRA_OUTPUT, currentPhotoUri)
        }
        startActivityForResult(intent, REQUEST_CAMERA)
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, REQUEST_IMAGE_PICK)
    }

    override fun onRequestPermissionsResult(reqCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(reqCode, permissions, results)
        if (reqCode == CAMERA_PERMISSION && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) {
            openCamera()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            when (requestCode) {
                REQUEST_CAMERA -> {
                    binding.ivReceiptPreview.visibility = android.view.View.VISIBLE
                    Glide.with(this).load(photoPath).into(binding.ivReceiptPreview)
                }
                REQUEST_IMAGE_PICK -> {
                    data?.data?.let { uri ->
                        photoPath = uri.toString()
                        binding.ivReceiptPreview.visibility = android.view.View.VISIBLE
                        Glide.with(this).load(uri).into(binding.ivReceiptPreview)
                    }
                }
            }
        }
    }

    private fun saveExpense() {
        val amountStr = binding.etAmount.text.toString().trim()
        val description = binding.etDescription.text.toString().trim()
        val date = binding.etDate.text.toString().trim()
        val startTime = binding.etStartTime.text.toString().trim()
        val endTime = binding.etEndTime.text.toString().trim()

        if (amountStr.isEmpty()) { binding.etAmount.error = "Enter amount"; return }
        if (description.isEmpty()) { binding.etDescription.error = "Enter description"; return }
        if (selectedCategoryId == -1) { Toast.makeText(this, "Select a category", Toast.LENGTH_SHORT).show(); return }

        val amount = amountStr.toDoubleOrNull()
        if (amount == null || amount <= 0) { binding.etAmount.error = "Invalid amount"; return }

        val expense = Expense(
            userId = userId,
            categoryId = selectedCategoryId,
            amount = amount,
            description = description,
            date = date,
            startTime = startTime,
            endTime = endTime,
            photoPath = photoPath
        )

        lifecycleScope.launch {
            db.expenseDao().insert(expense)
            runOnUiThread {
                Toast.makeText(this@AddExpenseActivity, "Expense saved!", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
