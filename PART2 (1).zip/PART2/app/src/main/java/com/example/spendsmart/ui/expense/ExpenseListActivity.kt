package com.example.spendsmart.ui.expense

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.spendsmart.R
import com.example.spendsmart.data.AppDatabase
import com.example.spendsmart.data.entity.Category
import com.example.spendsmart.data.entity.Expense
import com.example.spendsmart.databinding.ActivityExpenseListBinding
import com.example.spendsmart.utils.SessionManager
import java.util.*

class ExpenseListActivity : AppCompatActivity() {
    private lateinit var binding: ActivityExpenseListBinding
    private lateinit var db: AppDatabase
    private var userId = -1
    private var fromDate = ""
    private var toDate = ""
    private val categoryMap = mutableMapOf<Int, Category>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityExpenseListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Expense List"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        db = AppDatabase.getDatabase(this)
        userId = SessionManager.getUserId(this)

        val cal = Calendar.getInstance()
        toDate = "%04d-%02d-%02d".format(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH))
        cal.set(Calendar.DAY_OF_MONTH, 1)
        fromDate = "%04d-%02d-%02d".format(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH))

        binding.rvExpenses.layoutManager = LinearLayoutManager(this)
        updateDateLabels()

        binding.btnFromDate.setOnClickListener { pickDate(true) }
        binding.btnToDate.setOnClickListener { pickDate(false) }

        loadCategories()
    }

    private fun loadCategories() {
        db.categoryDao().getCategoriesByUser(userId).observe(this) { cats ->
            cats.forEach { categoryMap[it.id] = it }
            loadExpenses()
        }
    }

    private fun loadExpenses() {
        db.expenseDao().getExpensesByDateRange(userId, fromDate, toDate).observe(this) { expenses ->
            binding.tvEmpty.visibility = if (expenses.isEmpty()) View.VISIBLE else View.GONE
            val total = expenses.sumOf { it.amount }
            binding.tvTotal.text = "Total: R%.2f".format(total)
            binding.rvExpenses.adapter = ExpenseAdapter(expenses, categoryMap) { expense ->
                showExpenseDetail(expense)
            }
        }
    }

    private fun pickDate(isFrom: Boolean) {
        val cal = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            val date = "%04d-%02d-%02d".format(y, m+1, d)
            if (isFrom) fromDate = date else toDate = date
            updateDateLabels()
            loadExpenses()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun updateDateLabels() {
        binding.btnFromDate.text = "From: $fromDate"
        binding.btnToDate.text = "To: $toDate"
    }

    private fun showExpenseDetail(expense: Expense) {
        val cat = categoryMap[expense.categoryId]?.name ?: "Unknown"
        val msg = "Category: $cat\nDate: ${expense.date}\nTime: ${expense.startTime} – ${expense.endTime}\nAmount: R%.2f\nDescription: ${expense.description}".format(expense.amount)
        val builder = AlertDialog.Builder(this).setTitle("Expense Detail").setMessage(msg).setPositiveButton("Close", null)

        if (expense.photoPath != null) {
            builder.setNeutralButton("View Photo") { _, _ ->
                val imgView = android.widget.ImageView(this)
                Glide.with(this).load(expense.photoPath).into(imgView)
                AlertDialog.Builder(this).setView(imgView).setPositiveButton("Close", null).show()
            }
        }
        builder.show()
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}

class ExpenseAdapter(
    private val expenses: List<Expense>,
    private val categoryMap: Map<Int, Category>,
    private val onClick: (Expense) -> Unit
) : RecyclerView.Adapter<ExpenseAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvDate: TextView = view.findViewById(R.id.tvExpenseDate)
        val tvDesc: TextView = view.findViewById(R.id.tvExpenseDesc)
        val tvAmount: TextView = view.findViewById(R.id.tvExpenseAmount)
        val tvCategory: TextView = view.findViewById(R.id.tvExpenseCategory)
        val tvPhoto: TextView = view.findViewById(R.id.tvHasPhoto)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_expense, parent, false)
        return VH(v)
    }

    override fun getItemCount() = expenses.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val e = expenses[position]
        holder.tvDate.text = "${e.date} ${e.startTime}"
        holder.tvDesc.text = e.description
        holder.tvAmount.text = "R%.2f".format(e.amount)
        holder.tvCategory.text = categoryMap[e.categoryId]?.name ?: "?"
        holder.tvPhoto.visibility = if (e.photoPath != null) View.VISIBLE else View.GONE
        holder.itemView.setOnClickListener { onClick(e) }
    }
}
