package com.example.spendsmart.ui.goals

import android.os.Bundle
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.spendsmart.data.AppDatabase
import com.example.spendsmart.data.entity.BudgetGoal
import com.example.spendsmart.databinding.ActivityBudgetGoalsBinding
import com.example.spendsmart.utils.SessionManager
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class BudgetGoalsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityBudgetGoalsBinding
    private lateinit var db: AppDatabase
    private var userId = -1
    private var minGoal = 0.0
    private var maxGoal = 10000.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBudgetGoalsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Budget Goals"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        db = AppDatabase.getDatabase(this)
        userId = SessionManager.getUserId(this)

        val monthKey = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date())

        // SeekBar for minimum goal (0 - 20000)
        binding.seekBarMin.max = 20000
        binding.seekBarMin.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                minGoal = progress.toDouble()
                binding.tvMinValue.text = "Minimum: R%.2f".format(minGoal)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // SeekBar for maximum goal (0 - 50000)
        binding.seekBarMax.max = 50000
        binding.seekBarMax.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                maxGoal = progress.toDouble()
                binding.tvMaxValue.text = "Maximum: R%.2f".format(maxGoal)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Load existing goal
        db.budgetGoalDao().getGoalForMonth(userId, monthKey).observe(this) { goal ->
            goal?.let {
                minGoal = it.minMonthly
                maxGoal = it.maxMonthly
                binding.seekBarMin.progress = it.minMonthly.toInt()
                binding.seekBarMax.progress = it.maxMonthly.toInt()
                binding.tvMinValue.text = "Minimum: R%.2f".format(it.minMonthly)
                binding.tvMaxValue.text = "Maximum: R%.2f".format(it.maxMonthly)
            }
        }

        binding.btnSaveGoals.setOnClickListener {
            if (minGoal > maxGoal) {
                Toast.makeText(this, "Minimum cannot exceed maximum", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            lifecycleScope.launch {
                db.budgetGoalDao().insert(BudgetGoal(userId = userId, minMonthly = minGoal, maxMonthly = maxGoal, month = monthKey))
                runOnUiThread {
                    Toast.makeText(this@BudgetGoalsActivity, "Budget goals saved!", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
