package com.example.spendsmart.ui.login

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.spendsmart.data.AppDatabase
import com.example.spendsmart.data.entity.User
import com.example.spendsmart.databinding.ActivityLoginBinding
import com.example.spendsmart.ui.dashboard.DashboardActivity
import com.example.spendsmart.utils.SessionManager
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = AppDatabase.getDatabase(this)

        // Auto-login if session exists
        if (SessionManager.isLoggedIn(this)) {
            startDashboard()
            return
        }

        binding.btnLogin.setOnClickListener { handleLogin() }
        binding.btnRegister.setOnClickListener { handleRegister() }
    }

    private fun handleLogin() {
        val username = binding.etUsername.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch {
            val user = db.userDao().login(username, password)
            if (user != null) {
                SessionManager.saveSession(this@LoginActivity, user.id, user.username)
                startDashboard()
            } else {
                runOnUiThread {
                    Toast.makeText(this@LoginActivity, "Invalid username or password", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun handleRegister() {
        val username = binding.etUsername.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()

        if (username.isEmpty()) {
            binding.etUsername.error = "Username cannot be empty"
            return
        }
        if (password.length < 6) {
            binding.etPassword.error = "Password must be at least 6 characters"
            return
        }

        lifecycleScope.launch {
            val existing = db.userDao().getUserByUsername(username)
            if (existing != null) {
                runOnUiThread {
                    Toast.makeText(this@LoginActivity, "Username already taken", Toast.LENGTH_SHORT).show()
                }
                return@launch
            }
            val newId = db.userDao().insert(User(username = username, password = password))
            SessionManager.saveSession(this@LoginActivity, newId.toInt(), username)
            startDashboard()
        }
    }

    private fun startDashboard() {
        startActivity(Intent(this, DashboardActivity::class.java))
        finish()
    }
}
