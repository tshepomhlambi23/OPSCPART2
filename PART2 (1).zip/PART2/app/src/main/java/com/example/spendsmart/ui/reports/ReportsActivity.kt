package com.example.spendsmart.ui.reports

import android.app.DatePickerDialog
import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.spendsmart.data.AppDatabase
import com.example.spendsmart.databinding.ActivityReportsBinding
import com.example.spendsmart.utils.SessionManager
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import kotlinx.coroutines.launch
import java.util.*

class ReportsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityReportsBinding
    private lateinit var db: AppDatabase
    private var userId = -1
    private var fromDate = ""
    private var toDate = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReportsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Reports"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        db = AppDatabase.getDatabase(this)
        userId = SessionManager.getUserId(this)

        val cal = Calendar.getInstance()
        toDate = "%04d-%02d-%02d".format(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH))
        cal.set(Calendar.DAY_OF_MONTH, 1)
        fromDate = "%04d-%02d-%02d".format(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH))

        updateDateLabels()
        binding.btnFromDate.setOnClickListener { pickDate(true) }
        binding.btnToDate.setOnClickListener { pickDate(false) }

        loadCharts()
    }

    private fun loadCharts() {
        db.categoryDao().getCategoriesByUser(userId).observe(this) { cats ->
            val catMap = cats.associateBy { it.id }

            db.expenseDao().getTotalByCategory(userId, fromDate, toDate).observe(this) { totals ->
                if (totals.isEmpty()) {
                    binding.barChart.setNoDataText("No expenses in this period")
                    binding.pieChart.setNoDataText("No expenses in this period")
                    return@observe
                }

                // Bar Chart
                val barEntries = totals.mapIndexed { i, ct ->
                    BarEntry(i.toFloat(), ct.total.toFloat())
                }
                val labels = totals.map { catMap[it.categoryId]?.name ?: "?" }
                val barDataSet = BarDataSet(barEntries, "Spending by Category").apply {
                    colors = totals.mapIndexed { i, _ ->
                        try { Color.parseColor(catMap[totals[i].categoryId]?.color ?: "#4CAF50") }
                        catch (e: Exception) { Color.parseColor("#4CAF50") }
                    }
                    valueTextSize = 12f
                }
                binding.barChart.apply {
                    data = BarData(barDataSet)
                    xAxis.apply {
                        valueFormatter = IndexAxisValueFormatter(labels)
                        position = XAxis.XAxisPosition.BOTTOM
                        granularity = 1f
                        setDrawGridLines(false)
                    }
                    axisRight.isEnabled = false
                    description.isEnabled = false
                    animateY(1000)
                    invalidate()
                }

                // Pie Chart
                val pieEntries = totals.mapIndexed { i, ct ->
                    PieEntry(ct.total.toFloat(), catMap[ct.categoryId]?.name ?: "?")
                }
                val pieDataSet = PieDataSet(pieEntries, "").apply {
                    colors = totals.mapIndexed { i, _ ->
                        try { Color.parseColor(catMap[totals[i].categoryId]?.color ?: "#4CAF50") }
                        catch (e: Exception) { Color.parseColor("#4CAF50") }
                    }
                    valueTextSize = 12f
                    valueTextColor = Color.WHITE
                }
                binding.pieChart.apply {
                    data = PieData(pieDataSet)
                    description.isEnabled = false
                    isDrawHoleEnabled = true
                    holeRadius = 40f
                    setEntryLabelColor(Color.WHITE)
                    animateY(1000)
                    invalidate()
                }

                // Summary text
                val totalStr = totals.joinToString("\n") { ct ->
                    "${catMap[ct.categoryId]?.name ?: "?"}: R%.2f".format(ct.total)
                }
                binding.tvCategorySummary.text = "Spending Summary:\n$totalStr"
            }
        }
    }

    private fun pickDate(isFrom: Boolean) {
        val cal = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            val date = "%04d-%02d-%02d".format(y, m+1, d)
            if (isFrom) fromDate = date else toDate = date
            updateDateLabels()
            loadCharts()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun updateDateLabels() {
        binding.btnFromDate.text = "From: $fromDate"
        binding.btnToDate.text = "To: $toDate"
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
