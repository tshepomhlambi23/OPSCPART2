package com.example.spendsmart.utils

import android.content.Context
import android.content.SharedPreferences

object SessionManager {
    private const val PREF_NAME = "SpendSmartSession"
    private const val KEY_USER_ID = "userId"
    private const val KEY_USERNAME = "username"
    private const val KEY_LOGGED_IN = "isLoggedIn"

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    fun saveSession(context: Context, userId: Int, username: String) {
        prefs(context).edit().apply {
            putInt(KEY_USER_ID, userId)
            putString(KEY_USERNAME, username)
            putBoolean(KEY_LOGGED_IN, true)
            apply()
        }
    }

    fun getUserId(context: Context): Int = prefs(context).getInt(KEY_USER_ID, -1)
    fun getUsername(context: Context): String = prefs(context).getString(KEY_USERNAME, "") ?: ""
    fun isLoggedIn(context: Context): Boolean = prefs(context).getBoolean(KEY_LOGGED_IN, false)

    fun clearSession(context: Context) {
        prefs(context).edit().clear().apply()
    }
}
