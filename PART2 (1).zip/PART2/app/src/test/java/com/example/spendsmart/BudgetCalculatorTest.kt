package com.example.spendsmart

import org.junit.Test
import org.junit.Assert.*

/**
 * Unit tests for SpendSmart budget tracker.
 * These tests cover core business logic.
 */
class BudgetCalculatorTest {

    @Test
    fun testBudgetProgressWithinLimit() {
        val maxBudget = 5000.0
        val totalSpent = 2500.0
        val progress = ((totalSpent / maxBudget) * 100).toInt()
        assertEquals(50, progress)
    }

    @Test
    fun testBudgetProgressOverLimit() {
        val maxBudget = 5000.0
        val totalSpent = 6000.0
        val progress = ((totalSpent / maxBudget) * 100).toInt()
        assertTrue("Progress should exceed 100 when over budget", progress > 100)
    }

    @Test
    fun testBudgetProgressZeroSpend() {
        val maxBudget = 5000.0
        val totalSpent = 0.0
        val progress = ((totalSpent / maxBudget) * 100).toInt()
        assertEquals(0, progress)
    }

    @Test
    fun testMinCannotExceedMax() {
        val minGoal = 3000.0
        val maxGoal = 2000.0
        assertTrue("Min goal cannot exceed max goal", minGoal > maxGoal)
    }

    @Test
    fun testValidMinMaxGoal() {
        val minGoal = 1000.0
        val maxGoal = 5000.0
        assertTrue("Min should be less than max", minGoal < maxGoal)
    }

    @Test
    fun testAmountValidation() {
        val validAmount = "250.50"
        val invalidAmount = "abc"
        assertNotNull(validAmount.toDoubleOrNull())
        assertNull(invalidAmount.toDoubleOrNull())
    }

    @Test
    fun testPasswordMinLength() {
        val shortPass = "abc"
        val validPass = "password123"
        assertFalse("Short password should fail", shortPass.length >= 6)
        assertTrue("Valid password should pass", validPass.length >= 6)
    }

    @Test
    fun testUsernameNotEmpty() {
        val emptyUsername = ""
        val validUsername = "john"
        assertTrue("Empty username should fail", emptyUsername.isEmpty())
        assertFalse("Valid username should pass", validUsername.isEmpty())
    }

    @Test
    fun testCategoryTotalCalculation() {
        val amounts = listOf(100.0, 250.50, 75.25, 400.0)
        val total = amounts.sum()
        assertEquals(825.75, total, 0.01)
    }

    @Test
    fun testDateFormatting() {
        val year = 2025
        val month = 4
        val day = 27
        val formatted = "%04d-%02d-%02d".format(year, month, day)
        assertEquals("2025-04-27", formatted)
    }
}
